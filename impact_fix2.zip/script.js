/* ============================================
   THURSINA BRIKET — SCRIPT.JS (FINAL)
   Interaktivitas Website Artikel Briket
   ============================================ */

/* ===== 1. NAVBAR SCROLL EFFECT ===== */
const navbar = document.getElementById('navbar');
const topBtn = document.getElementById('topBtn');

window.addEventListener('scroll', () => {
  if (window.scrollY > 50) {
    navbar.classList.add('scrolled');
    topBtn.classList.add('show');
  } else {
    navbar.classList.remove('scrolled');
    topBtn.classList.remove('show');
  }
});

/* ===== 2. MENU TOGGLE (MOBILE) ===== */
const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');

menuToggle.addEventListener('click', () => {
  navLinks.classList.toggle('open');
  menuToggle.textContent = navLinks.classList.contains('open') ? '✕' : '☰';
});

// Tutup menu saat link diklik
document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    menuToggle.textContent = '☰';
  });
});

/* ===== 3. BACK TO TOP ===== */
topBtn.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

/* ===== 4. REVEAL ON SCROLL ===== */
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('active');
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

/* ===== 5. COUNTER ANIMATION ===== */
const counters = document.querySelectorAll('.stat-card .num');

const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const target = +el.dataset.count;
      let current = 0;
      const step = Math.max(1, target / 40);
      
      const update = () => {
        current += step;
        if (current >= target) {
          el.textContent = target + (target === 100 ? '%' : '+');
        } else {
          el.textContent = Math.floor(current);
          requestAnimationFrame(update);
        }
      };
      update();
      counterObserver.unobserve(el);
    }
  });
}, { threshold: 0.5 });

counters.forEach(c => counterObserver.observe(c));

/* ===== 6. EMBER / PARTIKEL API EFFECT ===== */
const hero = document.querySelector('.hero');
const emberEmojis = ['🔥', '✨', '🔥', '💫'];

function createEmber() {
  const ember = document.createElement('div');
  ember.className = 'ember';
  ember.textContent = emberEmojis[Math.floor(Math.random() * emberEmojis.length)];
  ember.style.left = Math.random() * 100 + '%';
  ember.style.animationDuration = (Math.random() * 6 + 8) + 's';
  ember.style.fontSize = (Math.random() * 1.5 + 1) + 'rem';
  ember.style.animationDelay = Math.random() * 5 + 's';
  hero.appendChild(ember);
  
  setTimeout(() => ember.remove(), 15000);
}

// Buat partikel awal
for (let i = 0; i < 8; i++) createEmber();
// Buat partikel terus-menerus
setInterval(createEmber, 2000);

/* ===== 7. SMOOTH SCROLL UNTUK ANCHOR ===== */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      const offsetTop = target.offsetTop - 70;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
    }
  });
});

/* ===== 8. HOVER EFFECT GALERI ===== */
document.querySelectorAll('.gallery-item').forEach(item => {
  item.addEventListener('mouseenter', () => {
    item.style.zIndex = '5';
  });
  item.addEventListener('mouseleave', () => {
    item.style.zIndex = '1';
  });
});

/* ===== 9. TAG PILL CLICK ANIMATION ===== */
document.querySelectorAll('.tag-pill').forEach(tag => {
  tag.addEventListener('click', () => {
    tag.style.transform = 'scale(0.9)';
    setTimeout(() => {
      tag.style.transform = '';
    }, 150);
  });
});

/* ===== 10. STEP TIMELINE ANIMASI BERTAHAP ===== */
const steps = document.querySelectorAll('.step');
const stepObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry, index) => {
    if (entry.isIntersecting) {
      setTimeout(() => {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateX(0)';
      }, index * 100);
      stepObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });

steps.forEach(step => {
  step.style.opacity = '0';
  step.style.transform = 'translateX(-30px)';
  step.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  stepObserver.observe(step);
});

/* ===== 11. LOG SAAT LOAD ===== */
console.log('%c🔥 Thursina Briket Initiative', 'color: #e76f51; font-size: 18px; font-weight: bold;');
console.log('%cMengubah limbah menjadi energi! 🌿', 'color: #2d6a4f; font-size: 13px;');